# CubeConverter
A while back i created a AHK-Script for the newly introduced fill functionality that came with the change of crafting materials tab.
The usage of this script is pretty straigt forward:

1. Start the CubeConverter.exe. It should now run in the background. It can be closed by accessing the system tray at the bottom right of your windows taskbar.
![alt text](https://i.imgur.com/StDYUzd.jpg)
2. Select the recipe you want to use (currently working are Upgrade Rare Item and Convert Crafting Materials 
3. Press CTRL + 5 for 1 slot items or CTRL + 6 for 2 slot items. Press and Hold U if you want to cancel the convert process. Press F1 if you forget the information.

Thats basically all there is to it. No need to configure the script for your screen resolution it just works out of the box.

[![paypal](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.me/DaLeberkasPepi)
